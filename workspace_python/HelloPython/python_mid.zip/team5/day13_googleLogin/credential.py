'''
Created on 25 Mar 2021

@author: shane
'''
CLIENT_ID = ''
CLIENT_SECRET = ''